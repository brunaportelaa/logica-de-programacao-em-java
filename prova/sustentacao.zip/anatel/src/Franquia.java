public class Franquia {
    String nome;
    String codigo;
    int quantidadeGB;

    @Override
    public String toString() {
        return "Franquia{" +
                "nome='" + nome + '\'' +
                ", codigo='" + codigo + '\'' +
                ", quantidadeGB=" + quantidadeGB +
                '}';
    }
}
