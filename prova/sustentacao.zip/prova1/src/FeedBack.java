public class FeedBack {
        public FeedBack(String texto){

        }

        private String texto;
        double nota;

        /*
            TODO
            A NOTA É UM VALOR POSITIVO DE 0 A 100, O ZERO PODE SER UM VALOR PADRÃO.
            O ESCORE É 1 PONTO PARA CADA QUARTO DA NOTA, PODENDO CHEGAR A NO MÁXIMO 4 E NO MÍNIMO 1;
         */
        public int getScore(){

        }
}
