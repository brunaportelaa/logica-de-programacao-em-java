public class FeedBack {
        private final int LIMITE_SCORE_UM = 25;
        private final int LIMITE_SCORE_DOIS = 50;
        private final int LIMITE_SCORE_TRES = 75;
        private String texto;
        double nota;

        public FeedBack(String texto, double nota){
                this.texto = texto;
                this.nota = nota;
                
        }

        public String toString() {
                return "-------FEEDBACK-------\n" +
                        "FEED: " + this.texto +
                        "\nATRIBUICAO: " + this.nota +
                        "\nSCORE: " + this.getScore();
        }

        /*
            TODO
            A NOTA É UM VALOR POSITIVO DE 0 A 100, O ZERO PODE SER UM VALOR PADRÃO.
            O ESCORE É 1 PONTO PARA CADA QUARTO DA NOTA, PODENDO CHEGAR A NO MÁXIMO 4 E NO MÍNIMO 1;
         */
        public int getScore() {
                int score;
                if (nota <= LIMITE_SCORE_UM) {
                        score = 1;
                } else {
                        if (nota > LIMITE_SCORE_UM && nota <= LIMITE_SCORE_DOIS) {
                                score = 2;
                        } else {
                                if (nota > LIMITE_SCORE_DOIS && nota <= LIMITE_SCORE_TRES) {
                                        score = 3;
                                } else {
                                        score = 4;
                                }
                        }
                }
                return score;
        }
}
