public class Turma {
    Aluno[] alunos;
    int totalAlunos;
    int totalBolsistas;
    int totalRegulares;
}