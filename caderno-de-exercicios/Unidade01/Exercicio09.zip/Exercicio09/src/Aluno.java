public class Aluno {
    String nome;
    long matricula;
    boolean bolsista;
}
